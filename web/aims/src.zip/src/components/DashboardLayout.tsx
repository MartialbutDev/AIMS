import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Brand } from './Brand'
import { Icon } from './Icons'
import { roleLabels } from '../types/auth'
import type { UserRole, UserSession } from '../types/auth'
import type { DashboardData } from '../types/dashboard'
import { AdminPages } from '../pages/admin/AdminPages'
import { CoordinatorPages } from '../pages/coordinator/CoordinatorPages'
import { DeanPages } from '../pages/dean/DeanPages'
import { CareerCenterPages } from '../pages/career-center/CareerCenterPages'
import { CompanyPages } from '../pages/company/CompanyPages'

interface DashboardLayoutProps {
  session: UserSession
  data: DashboardData
  onLogout: () => void
}

const NAV_BY_ROLE = {
  admin: [
    { label: 'Overview', slug: 'dashboard', icon: 'grid' },
    { label: 'Users', slug: 'users', icon: 'users' },
    { label: 'Assignments', slug: 'assignments', icon: 'file' },
    { label: 'Notifications', slug: 'notifications', icon: 'bell' },
    { label: 'Developer info', slug: 'developer-info', icon: 'file' },
  ],
  coordinator: [
    { label: 'Overview', slug: 'dashboard', icon: 'grid' },
    { label: 'Students', slug: 'students', icon: 'users' },
    { label: 'Applications', slug: 'applications', icon: 'file' },
    { label: 'Notifications', slug: 'notifications', icon: 'bell' },
  ],
  dean: [
    { label: 'Overview', slug: 'dashboard', icon: 'grid' },
    { label: 'Notifications', slug: 'notifications', icon: 'bell' },
  ],
  career_center: [
    { label: 'Overview', slug: 'dashboard', icon: 'grid' },
    { label: 'Companies', slug: 'companies', icon: 'briefcase' },
    { label: 'Applications', slug: 'applications', icon: 'file' },
    { label: 'Notifications', slug: 'notifications', icon: 'bell' },
    { label: 'Developer info', slug: 'developer-info', icon: 'file' },
  ],
  company: [
    { label: 'Overview', slug: 'dashboard', icon: 'grid' },
    { label: 'Applications', slug: 'applications', icon: 'users' },
    { label: 'Notifications', slug: 'notifications', icon: 'bell' },
    { label: 'Developer info', slug: 'developer-info', icon: 'file' },
  ],
} as const

const WORKSPACE_SLUGS: Record<UserRole, string> = {
  admin: 'admin',
  coordinator: 'coordinator',
  dean: 'dean',
  career_center: 'career-center',
  company: 'company',
}

export function DashboardLayout({
  session,
  data,
  onLogout,
}: DashboardLayoutProps) {
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileNavOpen, setMobileNavOpen] = useState(false)

  const section = location.pathname.split('/')[2] || 'dashboard'
  const navItems = NAV_BY_ROLE[session.role]

  const sectionLabels: Record<string, string> = {
    dashboard: 'Overview',
    users: 'Users',
    assignments: 'Assignments',
    students: 'Students',
    companies: 'Companies',
    applications: 'Applications',
    notifications: 'Notifications',
    'developer-info': 'Developer info',
    settings: 'Settings',
    'help-center': 'Help center',
  }

  const activeNav = sectionLabels[section] ?? 'Overview'
  const firstName = session.name || 'User'

  function goTo(nextSection: string) {
    navigate(`/${WORKSPACE_SLUGS[session.role]}/${nextSection}`)
    setMobileNavOpen(false)
  }

  let content

  switch (session.role) {
    case 'admin':
      content = (
        <AdminPages
          section={section}
          session={session}
          data={data}
          onLogout={onLogout}
          onNavigate={goTo}
        />
      )
      break

    case 'coordinator':
      content = (
        <CoordinatorPages
          section={section}
          session={session}
          data={data}
          onLogout={onLogout}
          onNavigate={goTo}
        />
      )
      break

    case 'dean':
      content = (
        <DeanPages
          section={section}
          session={session}
          onLogout={onLogout}
        />
      )
      break

    case 'career_center':
      content = (
        <CareerCenterPages
          section={section}
          session={session}
          data={data}
          onLogout={onLogout}
          onNavigate={goTo}
        />
      )
      break

    case 'company':
      content = (
        <CompanyPages
          section={section}
          session={session}
          data={data}
          onLogout={onLogout}
          onNavigate={goTo}
        />
      )
      break
  }

  return (
    <div className="dashboard-app">
      <aside
        className={`sidebar${mobileNavOpen ? ' sidebar--open' : ''}`}
      >
        <div className="sidebar-brand">
          <Brand compact />

          <button
            type="button"
            className="mobile-close"
            onClick={() => setMobileNavOpen(false)}
            aria-label="Close navigation"
          >
            ×
          </button>
        </div>

        <div className="workspace-label">YOUR WORKSPACE</div>

        <div className="workspace-switcher">
          <span
            className={`workspace-avatar workspace-avatar--${session.role}`}
          >
            {roleLabels[session.role].slice(0, 1)}
          </span>

          <span>
            <strong>{roleLabels[session.role]}</strong>
            <small>USTP Internship Office</small>
          </span>

          <Icon name="chevron" size={16} />
        </div>

        <div className="nav-label">MENU</div>

        <nav className="side-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <button
              type="button"
              className={`nav-item${
                section === item.slug ? ' nav-item--active' : ''
              }`}
              key={item.slug}
              aria-current={
                section === item.slug ? 'page' : undefined
              }
              onClick={() => goTo(item.slug)}
            >
              <Icon name={item.icon} size={18} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="nav-label">PREFERENCES</div>

          <button
            type="button"
            className={`nav-item${
              section === 'settings' ? ' nav-item--active' : ''
            }`}
            aria-current={
              section === 'settings' ? 'page' : undefined
            }
            onClick={() => goTo('settings')}
          >
            <Icon name="settings" size={18} />
            <span>Settings</span>
          </button>

          <button
            type="button"
            className={`nav-item${
              section === 'help-center' ? ' nav-item--active' : ''
            }`}
            aria-current={
              section === 'help-center' ? 'page' : undefined
            }
            onClick={() => goTo('help-center')}
          >
            <Icon name="help" size={18} />
            <span>Help center</span>
          </button>

          <div className="sidebar-user">
            <span className="user-avatar">
              {firstName.slice(0, 1).toUpperCase()}
            </span>

            <span className="sidebar-user-copy">
              <strong>{firstName}</strong>
              <small>{roleLabels[session.role]}</small>
            </span>

            <button
              type="button"
              className="logout-button"
              onClick={onLogout}
              aria-label="Sign out"
            >
              <Icon name="logout" size={17} />
            </button>
          </div>
        </div>
      </aside>

      {mobileNavOpen && (
        <button
          type="button"
          className="sidebar-scrim"
          onClick={() => setMobileNavOpen(false)}
          aria-label="Close navigation"
        />
      )}

      <main className="dashboard-main">
        <header className="topbar">
          <button
            type="button"
            className="mobile-menu"
            onClick={() => setMobileNavOpen(true)}
            aria-label="Open navigation"
          >
            <Icon name="menu" size={20} />
          </button>

          <div className="breadcrumbs">
            <span>Workspace</span>
            <Icon name="chevron" size={14} />
            <strong>{activeNav}</strong>
          </div>

          <div className="topbar-actions">
            <span className="today-label">
              <Icon name="clock" size={15} />
              Today
            </span>

            <button
              type="button"
              className="topbar-avatar"
              title="Open account settings"
              onClick={() => goTo('settings')}
            >
              {firstName.slice(0, 1).toUpperCase()}
            </button>
          </div>
        </header>

        <div className="dashboard-content">{content}</div>
      </main>
    </div>
  )
}